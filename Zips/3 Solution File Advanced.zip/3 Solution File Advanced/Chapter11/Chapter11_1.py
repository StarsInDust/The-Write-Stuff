text = "Just a bit of text going on here"
number = 15
floating = 9.532


with open('aDataFile', 'w') as file:
    file.write(text + '\n')
    file.write(str(number) + '\n')
    file.write(str(floating) + '\n')

