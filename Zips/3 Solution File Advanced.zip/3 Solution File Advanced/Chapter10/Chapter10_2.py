
from queue import Queue


if __name__ == "__main__":

    #Create a queue object
     a = 10
    
     myQ = Queue()
     myQ.put(a)
    

     theFirst = myQ.get()
     print(theFirst)

    
     print('The Job has finished')

