from threading import Thread, Lock, current_thread
from queue import Queue

def workman(myQ, lock):
    while True:
        value = myQ.get()  
        with lock:
            
            print(f"in {current_thread().name} got {value}")
        

        
        myQ.task_done()

if __name__ == '__main__':
    myQ = Queue()
    num_threads = 10
    lock = Lock()

    for i in range(num_threads):
        t = Thread(name=f"Thread{i+1}", target=workman, args=(myQ, lock))
        t.daemon = True  # dies when the main thread dies
        t.start()
    
    # This fills the queue with items
    for x in range(20):
        myQ.put(x)

    myQ.join()  

    print('The job has finished')

