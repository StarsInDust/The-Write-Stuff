def fibonacci (numbers):
    num1, num2 =0,1
    while num1 < numbers:
        yield num1
        num1, num2 = num2, num1 + num2


myFibonacci = fibonacci (45)

for i in myFibonacci:
    print(i)