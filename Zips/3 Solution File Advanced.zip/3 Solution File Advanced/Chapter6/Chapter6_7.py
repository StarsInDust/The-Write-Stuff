def bracelet(x):
    beads =[]
    bead = 10
    
    while bead > x:
        beads.append(bead)
        bead -= 1
    return beads


def myGenerator(x):
    bead = 10
    while bead > x:
        yield bead
        bead -=1


print(bracelet(0))
print(" ")
print(sum(myGenerator(0)))
