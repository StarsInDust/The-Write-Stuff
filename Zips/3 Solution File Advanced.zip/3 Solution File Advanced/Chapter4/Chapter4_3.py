import itertools


myRepeat = list(itertools.repeat('I love itertools', 4))

myMessage = " ".join(myRepeat)

print(myMessage)


