import itertools

# for in loop
for i in itertools.count(3, 3):
    if i == 27:
        break
    else:
        print(i, end =" ")