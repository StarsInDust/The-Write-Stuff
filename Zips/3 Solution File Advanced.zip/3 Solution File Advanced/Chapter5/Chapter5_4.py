import functools

def repeat(repeating):
    def decoratorRepeat(func):
        @functools.wraps(func)
        def wrapItUp(*args, **kwargs):
            for _ in range(repeating):
                answer = func(*args, **kwargs)
            return answer
        return wrapItUp
    return decoratorRepeat
def myDecorator(func):

    @functools.wraps(func)
    def wrapItup(*args, **kwargs):
        print('before function call')
        answer = func(*args, **kwargs)
        print('after function call')
        return answer
    return wrapItup

def debugger(func):
    @functools.wraps(func)
    def wrapItUp(*args, **kwargs):
        argsRepr = [repr(a) for a in args] 
        kwargsRepr = [f"{k}={v!r}" for k, v in kwargs.items()] 
        signature = ", ".join(argsRepr + kwargsRepr)
        print(f"Calling {func.__name__}({signature})")
        result = func(*args, **kwargs)
        print(f"{func.__name__!r} returned {result!r}")
        return result
    return wrapItUp

@debugger
@myDecorator
@repeat(repeating = 5)
def welcome(name):
    print(f'Are you a good witch, or a bad witch {name}')

welcome("Sabrinna")
