def wrapMyFunction(functionPlace):

    def wrapItUp():

        print("This is before your function is run:")
        functionPlace()
        print("Your function has been ran.")

    return wrapItUp
    


@wrapMyFunction
def greetings():
    print("Greetings Earthlings")
    

greetings()