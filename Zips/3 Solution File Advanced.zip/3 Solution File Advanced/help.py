import logging
#from logging.handlers import RotatingFileHandler

from logging.handlers import TimedRotatingFileHandler
import time

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

#This will roll over after 2kb, so it will produce multiple files.
'''handler = RotatingFileHandler('app.log', maxBytes=2000, backupCount=5)
logger.addHandler(handler)


for _ in range(10000):
    logger.info('Good Day Everyone!')'''



handler = TimedRotatingFileHandler('myTimedLog', when='s', interval=5, backupCount=5)
logger.addHandler(handler)


for _ in range(6):
    logger.info('I am being created every 5 seconds')

    time.sleep(5)
