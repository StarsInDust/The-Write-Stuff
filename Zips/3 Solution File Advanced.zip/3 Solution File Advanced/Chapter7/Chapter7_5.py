import re

myText = "John Mary Sam Norma Pete Andrea"
replaceIt = re.sub("\s", "-", myText)
print(replaceIt)
