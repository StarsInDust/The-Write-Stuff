import re

myText = "Super-cali-fradgi-listic-expi-ali-docious"

findText= re.findall('li', myText)
print(findText)
