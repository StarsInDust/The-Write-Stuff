import re

phone_regex = '^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$'
phone_number = '(248) 123-7890'
matchMe = re.search(phone_regex, phone_number)

print(matchMe)





