import re

#Split will split the string at the white space, add commas and put into quotes and square brackets for us.

myText = "John Mary Sam Norma Pete Andrea."
listThis = re.split("\s", myText)
print(listThis)

