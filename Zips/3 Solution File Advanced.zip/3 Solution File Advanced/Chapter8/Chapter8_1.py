
from multiprocessing import Process
import os
import time

def addNumbers():
    for i in range(50):
        result = i + 1
        time.sleep(0.1)


if __name__ == "__main__":
    processes =[]
    num_processes = os.cpu_count()


    for i in range(num_processes):
        process = Process(target=addNumbers)
        processes.append(process)


    for process in processes:
        process.start()
         
    for process in processes:
        process.join()

    print("The job has finally finished")



