from threading import Thread
import time


def addNumbers():
    for i in range(50):
        answer = i + 1
        time.sleep(0.1)

        
if __name__ == "__main__":
    threads = []
    num_threads = 10

    for i in range(num_threads):
        thread = Thread(target=addNumbers)
        threads.append(thread)


    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()

    print("The job has finally finished")
        
