
# import Lock
from threading import Thread, Lock
import time

databaseValue = 0

def increase(lock):
    global databaseValue 
    
    with lock: 
        local_copy = databaseValue
        local_copy += 1
        time.sleep(0.1)
        databaseValue = local_copy

if __name__ == "__main__":

    # create a lock
    lock = Lock()
    
    print('Starting Job: ', databaseValue)

    # pass the lock to the target function
    thread1 = Thread(target=increase, args=(lock,)) # notice the comma after lock since args must be a tuple
    thread2 = Thread(target=increase, args=(lock,))

    thread1.start()
    thread2.start()

    thread1.join()
    thread2.join()

    print('Starting Job:', databaseValue)

    print('The Job has finished')
