

import pathlib

file_path = pathlib.Path("C:\\Users\\stars\\Desktop\\hello.txt")

with file_path.open("w") as file:
    file.write("This file is on desk top. You must escape backslashes with backslashes")