

import pathlib

file_path = pathlib.Path("hello.txt")

with file_path.open("w") as file:
    file.write("Just another file. This will create the file if it is not there.")



'''file_path = pathlib.Path("C:\\Users\\[your User Name]\\Desktop\\hello.txt")

with file_path.open("w") as file:
    file.write("This file is on desk top. You must escape backslashes with backslashes")'''