
import copy


originalObject =[[0,1,2,],[3,4,5], [6,7,8]]
myCopiedObject = copy.copy(originalObject)


originalObject[1][1] = 'Ah-ha, I am changed'


print("Old list:", originalObject)

print("New list:", myCopiedObject)



