import copy

class Pet:
    def __init__(self, name, age, species):
        self.name = name
        self.age = age
        self.species = species
        

myDog = Pet("Brandy", 3, "Dog")
myDog2 = copy.copy(myDog)

myDog2.name = "Chase"
print(myDog2.name)
print(myDog.name)
