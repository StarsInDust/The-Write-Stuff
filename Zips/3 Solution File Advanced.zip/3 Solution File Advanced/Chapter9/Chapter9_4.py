from multiprocessing import Process, Value, Array, Lock
import time

def addNum(nums, lock):
    for i in range(100):
        time.sleep(0.1)
        for i in range(len(nums)):
            with lock:
                nums[i] += 2
          

if __name__ == '__main__':
    lock = Lock()
    sharedArray = Array('d', [0.0, 100.0, 200.0])
    print("The array's starting number is: ", sharedArray[:])
   

    process1 = Process(target= addNum, args=(sharedArray, lock,))
    process2 = Process(target= addNum, args=(sharedArray, lock,))

    process1.start()
    process2.start()

    process1.join()
    process2.join()

    print('This is what we will have in our array at the end: ',sharedArray[:])

