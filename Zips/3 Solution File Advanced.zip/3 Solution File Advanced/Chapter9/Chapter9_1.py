from multiprocessing import Process, Value, Array
import time

def addNum(num):
    for i in range(100):
        num.value += 2


if __name__ == '__main__':
    sharedNum = Value('i', 0)
    print('The starting number is: ', sharedNum.value)






