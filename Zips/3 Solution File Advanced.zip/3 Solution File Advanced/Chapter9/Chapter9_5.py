from multiprocessing import Process, Value, Array, Lock
from multiprocessing import Queue
import time

def addNums(nums, queue, lock):
    for i in nums: 
        queue.put(i+i)

def reverseNums(nums, queue, lock): 
    for i in nums: 
        queue.put(i*-1)
          

if __name__ == '__main__':

    lock = Lock()
    
    #Set the variable to = the queue object, we know it is an object because of the parenthsis following it.

    nums = range(1, 10)
    myQ = Queue()
    
#create two processes
    
    process1 = Process(target=addNums, args=(nums,myQ, lock,))
    process2 = Process(target=reverseNums, args=(nums,myQ, lock,))

    process1.start()
    process2.start()

    process1.join()
    process2.join()

    # order might not be sequential
    while not myQ.empty():
        print(myQ.get())
        
    print('This is The End ')

