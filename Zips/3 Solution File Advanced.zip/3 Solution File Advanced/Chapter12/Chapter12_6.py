# Then use the config file in the code
import logging
import logging.config

logging.config.fileConfig('logging.conf')

# Below we create a logger using the name we get from the config file

logger = logging.getLogger('myExample')

logger.debug('Commencing To Debug Now...')
logger.info('For Your Information Only')