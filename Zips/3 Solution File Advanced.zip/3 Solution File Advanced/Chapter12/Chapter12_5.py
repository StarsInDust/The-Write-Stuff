import logging
logger = logging.getLogger(__name__)


#1 Create the Handler
streamHandler = logging.StreamHandler()
fileHandler = logging.FileHandler('file.log')

#2 Set the levels of Handlers
streamHandler.setLevel(logging.WARNING)
fileHandler.setLevel(logging.ERROR)


#3 Formating the Loggers
formatLine = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
streamHandler.setFormatter(formatLine)
fileHandler.setFormatter(formatLine)



#4 Adding the Handlers
logger.addHandler(streamHandler)
logger.addHandler(fileHandler)

#5 Setting up the Messages
logger.warning('Warning, Warning, Warning, Will Robinson')
logger.error('Opps, this is an error')


