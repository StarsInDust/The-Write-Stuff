import logging
import traceback

#Example 1

'''myLogger = logging.getLogger(__name__)
myLogger.info('I am informing you, I am here.')'''


#Example 2, this is used with Stack Trace. Remember to comment out the two lines above, and only leave the import statement when you uncomment these following lines to use.

'''try:
    x=[2,4,6,8]
    myIndex = x[5]
except IndexError as e:
    logging.error(e, exc_info=True)
                
'''

#Example 3 Except with no specific error specified

try:
    x=[2,4,6,8]
    myIndex = x[5]
except:
    logging.error('The error is %s', traceback.format_exc())

