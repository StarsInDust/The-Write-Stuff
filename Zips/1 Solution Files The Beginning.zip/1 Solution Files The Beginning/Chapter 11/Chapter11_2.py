#determine if adult

yourAge = 20

if yourAge < 18:
    print('You are a child, you cannot drink, or vote.')

else:
    print("Let's go Vote!")
