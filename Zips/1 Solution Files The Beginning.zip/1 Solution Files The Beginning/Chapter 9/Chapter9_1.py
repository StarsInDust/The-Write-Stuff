
def addMe (x, y):
    return x + y

myAnswer = addMe(5, 5)
print(myAnswer)