def modulusMe (x, y):
    return x % y

myAnswer = modulusMe(33, 5)
print(myAnswer)