import random

lowNumber = 1
highNumber = 100


myNumber = random.random()
print("{:.2f}".format(myNumber))