import random

myPicks = ["witch", "dragon", "unicorn"]
random.shuffle(myPicks)

print(myPicks)