import random

lowNumber = 1
highNumber = 100


myNumber = random.randint(lowNumber, highNumber)
print(myNumber)