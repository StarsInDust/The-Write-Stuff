def floorMe (x, y):
    return x // y

myAnswer = floorMe(73, 5)
print(myAnswer)