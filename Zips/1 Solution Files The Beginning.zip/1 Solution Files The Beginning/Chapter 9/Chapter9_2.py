def subtractMe (x, y):
    return x - y

myAnswer = subtractMe(20, 5)
print(myAnswer)