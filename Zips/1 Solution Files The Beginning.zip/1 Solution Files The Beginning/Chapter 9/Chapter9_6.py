def exponentMe (x, y):
    return x ** y

myAnswer = exponentMe(5, 3)
print(myAnswer)