try:
    x = 5/0
except:
    print('You cannot divide by 0')



