
import a_Function as f

f.a_function()



