
def nameFunction(firstName, lastName):
    print(firstName + " " + lastName)

nameFunction('Lovely', 'Day')
nameFunction('June', 'Bug')
nameFunction('Swift', 'River')