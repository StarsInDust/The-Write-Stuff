def groceries(apple, banana, cantalope, *args, **kwargs):
    print(apple, banana, cantalope)
    for arg in args:
        print(arg)
    for key in kwargs:
        print(key, kwargs[key])

groceries(1,2,3,4,5,6,7,eight = ': pear', nine = ': pineapple')