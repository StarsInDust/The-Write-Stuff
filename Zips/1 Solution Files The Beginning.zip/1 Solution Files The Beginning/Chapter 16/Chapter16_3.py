myMood = ['Happy'] * 3
print(myMood)
