myTuple = ("Horse","Cow","Duck",)
mySet = {"Monkey","Dog","Cat"}

myNewList = [*myTuple, *mySet]
print(myNewList)
