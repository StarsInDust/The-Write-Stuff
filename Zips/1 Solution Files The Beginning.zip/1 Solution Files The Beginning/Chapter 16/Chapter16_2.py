myAnswer = 8 ** 2
print(myAnswer)