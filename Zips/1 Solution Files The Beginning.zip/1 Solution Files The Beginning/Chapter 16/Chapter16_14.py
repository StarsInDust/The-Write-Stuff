myTuple = ("Horse","Cow","Duck",)
mySecondTuple = ("Monkey","Dog","Cat",)

myNewList = [*myTuple, *mySecondTuple]
print(myNewList)
