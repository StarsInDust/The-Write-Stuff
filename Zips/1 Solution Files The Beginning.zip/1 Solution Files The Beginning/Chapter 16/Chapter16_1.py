myAnswer = 8 * 7
print(myAnswer)