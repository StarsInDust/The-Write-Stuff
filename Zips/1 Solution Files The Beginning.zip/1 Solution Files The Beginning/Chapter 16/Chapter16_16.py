myDictionary1= {'Bob': 8, 'Sam': 6, 'Gary': 9}
myDictionary2= {'Sara': 5, 'Ann': 6, 'Mary': 10}
myDictionary3= {**myDictionary1, **myDictionary2}
print(myDictionary3)
