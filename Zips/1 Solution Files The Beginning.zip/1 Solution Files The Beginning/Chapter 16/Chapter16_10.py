def groceries(apple, banana, cantalope,):
    print(apple, banana, cantalope)
aDictionary = {'apple' : 1,'banana' : 2,'cantalope' : 3}
groceries(**aDictionary)