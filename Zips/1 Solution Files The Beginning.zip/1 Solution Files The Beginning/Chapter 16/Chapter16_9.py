myList =('lime','onion', 'pear',)
print(*myList)