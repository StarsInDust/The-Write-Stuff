class Pet:
    def __init__(self, pet_name, breed, age):
        self.pet_name = pet_name
        self.breed = breed
        self.age = age
       
#The __str__ dunder method returns a string representation of the object
    def __str__(self):

        return f"{self.pet_name} is a {self.breed} and is {self.age} years old"

#Creating the new object and printing it out 

new_Pet = Pet("Tinker", "Pomeranian", 11)
print(new_Pet)