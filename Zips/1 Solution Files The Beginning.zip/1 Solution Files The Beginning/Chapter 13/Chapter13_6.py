


aLittleString = '''


This is just a little string that says





    'Hello!'


'''

print(aLittleString)

