name = "Sara"
age = 23

print(F"Hello, {name}. You are {age}")
print(f"In 5 years you will be: {age +5}")