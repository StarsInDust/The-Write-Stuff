
name = "Sara"
age = 23

print(F"Hello, {name}. You are {age}")