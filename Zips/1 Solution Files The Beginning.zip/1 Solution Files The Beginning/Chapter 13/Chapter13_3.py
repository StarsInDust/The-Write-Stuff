def toUpperCase(input):
    return input.upper()


Profession = "Doctor"
myProfession = f"{toUpperCase(Profession)}: Michael Steal"
print(myProfession)


