#Setting our variable at the top
Lime = "\033[32m"
bold = "\033[1m"
dark = "\033[2m"
normal = "\033[22m"

#Using the variable: Lime, to print the color
print(Lime + "Do you like the color lime")

#Adding the color code directly to print statement
print("\033[34m" + "Maybe instead you would rather have blue")

# Or add the entire thing to the print statement
print("\033[35mOk, so now I am purple")

print("\33[0mOk, now I am feeling my old self again")

print(dark + "This is what the dark them looks like")
print(normal + "This is what the normal theme looks like")