class Employee:
    def __init__(self, name, title, yearsOnJob):
        self.name = name
        self.title = title
        self.yearsOnJob = yearsOnJob

e1 = Employee("Jason", 46, 5)

print(e1.name)
print(e1.title)
print(e1.yearsOnJob)