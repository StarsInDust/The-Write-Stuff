def MenuItem():
    print('Will you be eating Fish, Chicken or Beef, Today?')
    x = input()
    print('The menu item that you have chosen is: ' + x)