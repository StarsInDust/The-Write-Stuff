def nameOfParty():
    print('Enter your name: ')
    x = input()
    print('The name of party eating with us today is: ' + x)