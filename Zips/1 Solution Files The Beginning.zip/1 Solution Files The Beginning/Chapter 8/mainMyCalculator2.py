from myCalculator import add, subtract

print(add(1,2))
print(subtract(8,2))
