import myCalculator as cal

print(cal.add(1,2))
print(cal.subtract(8,2))
