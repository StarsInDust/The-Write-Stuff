from myCalculator import add

print(add(1,2))
