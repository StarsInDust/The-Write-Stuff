from  myPackage.module1 import *
from  myPackage.module2 import *

nameOfParty()
MenuItem()