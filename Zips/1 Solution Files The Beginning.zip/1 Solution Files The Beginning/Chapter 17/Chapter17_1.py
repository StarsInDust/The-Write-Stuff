x =lambda a : a * 15
print(x(22))