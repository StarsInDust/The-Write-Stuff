def aFunction (multiplier):
    return lambda myNum : myNum * multiplier

MultiplyByTwo = aFunction(2)
MultiplyByThree = aFunction(3)
MultiplyByFour = aFunction(4)

print(MultiplyByTwo(5))
print(MultiplyByThree(2))
print(MultiplyByFour(6))

