i = 1
while i <= 10:
    if i == 6:
        print('I am the big bad number 6!')

    else:
        print(i)
    i += 1