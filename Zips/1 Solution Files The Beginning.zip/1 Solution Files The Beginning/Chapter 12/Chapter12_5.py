myList = [1, 2, 3, 4, 5]
for number in myList:
    print("This is my message and Thank you very much!")
