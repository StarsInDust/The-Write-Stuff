myDictionary = {
    "name": "Sam",
    "age": 30,
    "profession": "writer"
}

for key, value in myDictionary.items():
    print(f"{key}:{myDictionary[key]}")