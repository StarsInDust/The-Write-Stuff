# using an input and a while loop to get user's password.

password = ''

while True:
    password = input('Please enter your password: ')

    if len(password) < 4:
        print('Sorry your password is too short, please create one with more than 4 letters')
        continue
    else:
        print(f'Here is your password: {password}')
        break



