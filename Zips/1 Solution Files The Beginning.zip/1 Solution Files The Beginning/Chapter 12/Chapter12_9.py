myFruitTupple = ("apple", "banana", "peach" )
for item in myFruitTupple:
    print(item)
else:
    print("...and there ain't no more")