myDictionary = {
    "name": "Sam",
    "age": 30,
    "profession": "writer"
}

print(myDictionary["name"])
print(myDictionary["age"])
print(myDictionary["profession"])
