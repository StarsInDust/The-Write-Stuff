myFruitTupple = ("apple", "banana", "peach" )
print(myFruitTupple)