numbers = [0,1,2,3,4]

for i in range(4, 11):
        numbers.append(i+1)
        print(numbers)