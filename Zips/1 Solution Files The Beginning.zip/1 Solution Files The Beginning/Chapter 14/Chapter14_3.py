try:
    x= 5/0
except ZeroDivisionError:
    print('You cannot divide by 0')

try:
    y = 5 + "5"
except TypeError:
    print("You cannot add a number and a string (type error)")
