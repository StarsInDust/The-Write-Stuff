x = 0
if x ==0:

    raise Exception('x should not be 0')