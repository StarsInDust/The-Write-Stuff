x = -4

if x < 0:
    raise Exception('Please make x positive')