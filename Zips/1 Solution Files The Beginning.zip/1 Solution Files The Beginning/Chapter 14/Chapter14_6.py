class NumTooHigh(Exception):
    def __init__(self,message, value):
        self.message = message
        self.value = value

def checkNumber(x):
    if x > 50:
         raise NumTooHigh('This number is too high', x)
    else:
        print(x)

try:
    myAnswer = checkNumber(300)
except NumTooHigh as e:
     print(e.message, e.value)
