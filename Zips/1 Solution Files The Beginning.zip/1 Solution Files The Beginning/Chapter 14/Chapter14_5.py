try:
    x= 10/0
except ZeroDivisionError:
    print('You cannot divide by 0')

try:
    y = 5 + "5"
except TypeError:
    print("You cannot add a number and a string (type error)")

else:
    print('All is right with the world here!')

finally:
    print("The maid has entered the building, the program is now in cleanup mode")