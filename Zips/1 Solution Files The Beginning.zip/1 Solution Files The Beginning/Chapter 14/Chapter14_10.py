x = -9
assert (x >= 0), 'Opps your number is either 0 or less than 0'