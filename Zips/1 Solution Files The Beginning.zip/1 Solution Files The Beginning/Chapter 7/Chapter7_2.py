class Food:    
    def __init__(self, name, meal):
        self.name = name
        self.meal = meal

    def printFood(self):
        print(f"The name of the meal is {self.name} and it is eaten at {self.meal} time")

#We set a variable to equal the class of Food, and then we call the print function, we created above to print the message.

cinnamonToast = Food("Cinnamon Toast", "Breakfast")
cinnamonToast.printFood()

class Fish(Food):
    pass

fishDinner = Fish("Herb and Butter Fish", "Dinner")
fishDinner.printFood()

