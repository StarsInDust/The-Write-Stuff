class Food:    
    def __init__(self, name, meal):
        self.name = name
        self.meal = meal

    def printFood(self):
        print(f"The name of the meal is {self.name} and it is eaten at {self.meal} time")

#We set a variable to equal the class of Food, and then we call the print function, we created above to print the message.

cinnamonToast = Food("Cinnamon Toast", "Breakfast")
cinnamonToast.printFood()

class Fish(Food):
    def __init__(self, name, meal, numInParty):
        super().__init__(name, meal)
        self.numInParty = numInParty

    def printFish(self):
        print(f"The meal today is {self.name},and it is now, {self.meal}, and we will be serving {self.numInParty} people this evening ")
    

fishDinner = Fish("Herb and Butter Fish", "Dinner", 4)
fishDinner.printFood()

