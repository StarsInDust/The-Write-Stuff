firstNumber = 2
secondNumber = 2

sum = firstNumber + secondNumber
print(sum)

