x = 35
print(x)