import calendar as myCal

print(dir(myCal))

