from datetime import time

x = time(hour=4)

print(x)


