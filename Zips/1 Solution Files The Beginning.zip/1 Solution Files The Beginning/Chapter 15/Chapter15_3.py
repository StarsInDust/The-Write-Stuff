
#Create a list to work with
filterList =[1,2,3,4,5,6,7,8,9,10]

#use anonymour funtion to filter, and then return only odd numbers

answerMe = list(filter(lambda x: (x % 2 == 1), filterList))

#print the answer
print(answerMe)

