myList =[5,10,15,20,25]
listComprehension = [x- 1 for x in myList]

print(listComprehension)