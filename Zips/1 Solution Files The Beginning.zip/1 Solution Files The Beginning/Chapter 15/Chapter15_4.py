def addThree(x):
    

    return x + 3

numbers = [1,2,3,4,5,6,7,8,9,10]
numbersPlusThree = list(map(addThree, numbers))

print(numbersPlusThree)