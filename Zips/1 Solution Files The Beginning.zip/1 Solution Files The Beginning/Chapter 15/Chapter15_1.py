myList =[5,10,15,20,25]
myNextList = map(lambda x: x-1, myList)

print(list(myNextList))