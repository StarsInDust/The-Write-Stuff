def doMath(a, b):
    Subtract = a - b 
    TurnIntoDecimal = (Subtract/a)*100
    return Subtract, TurnIntoDecimal


    '''First we do our calculation, each one, set to variables
     on two seperate lines, then we return the two variables
    that we used to store the calculations'''

Subtract, TurnIntoDecimal = doMath(100, 15)
print(Subtract)
print(TurnIntoDecimal)
