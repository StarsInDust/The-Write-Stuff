def returnToMe (x):
    return x + x

myAnswer = returnToMe(5)
print(myAnswer)