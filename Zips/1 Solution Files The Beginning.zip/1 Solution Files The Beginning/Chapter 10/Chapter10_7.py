def nextCube():
    i = 1

    while True:
        yield i * i * i
        i += 1   # += is a shortcut operator to saying:  i + 1 = i
                 # The next excution continues after this point.


#This next section of code will stop the infinite loop, we tell it if number is greater than 100, we want the code to stop.

#This next code will test a number in the nextCube function that we wrote above.
for num in nextCube():
    if num > 100:
        break
    print(num)
