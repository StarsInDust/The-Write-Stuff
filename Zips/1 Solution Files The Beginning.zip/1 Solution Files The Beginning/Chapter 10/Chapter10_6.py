def aPrintStatement():
    print("I am 'printing' from inside a function definition" )

def returningStringOfText():
    return "I am 'returning' from inside a function definition"


#We have to print before the return statement below, nothing is done after a return statement. return forces it out of the definition.

def addingTwoNumbers(a, b):
    print("This number is from a calculation inside a function definition")
    sum = a + b
    return sum

#Function calls below, remember if we do not call them they do not run

printStatement = aPrintStatement()
returnStatement = returningStringOfText()
returnTwoNumbers = addingTwoNumbers(5,8)

print(returnStatement)

print(returnTwoNumbers)
