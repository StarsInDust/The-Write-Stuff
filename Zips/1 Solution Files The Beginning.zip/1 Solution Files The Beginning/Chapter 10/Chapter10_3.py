def tripleThis(x):
    answer = x * x * x
    return answer

tripled = 10
result = tripleThis(tripled)
print("The result of {} tripled, is: {}.".format(tripled, result))
