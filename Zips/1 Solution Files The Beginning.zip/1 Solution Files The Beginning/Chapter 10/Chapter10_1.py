def returnToMe(x):
    return x

myAnswer = returnToMe(5)
print(myAnswer)

