coffee = "Strawberries & Creme Frappuccino"

def calculateMyPrice(coffee):
    if coffee == "Pumpkin Spice Latte":
        return 4.95

def calculateMyPrice(coffee):
    if coffee == "Caramel Frappuccino":
        return 3.95

def calculateMyPrice(coffee):
    if coffee == "Cinnamon Dolce Latte":
        return 4.65


def calculateMyPrice(coffee):
    if coffee == "Strawberries & Creme Frappuccino":
        return 3.75

    else:
        return 5.00

myCoffee = calculateMyPrice(coffee)
print("{:.2f}".format(myCoffee) )