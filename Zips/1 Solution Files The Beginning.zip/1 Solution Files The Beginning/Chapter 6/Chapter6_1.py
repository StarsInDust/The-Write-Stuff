class Novel():
    
    pageWidth = 8.5
    colorOfCover = "maroon"

    def __init__(self, name, writer, wordLength):
        self.name = name
        self.writer = writer
        self.wordLength = wordLength

    def __str__(self):
        return "~" + self.name + ", by " + self.writer + "~"

    def numberOfPages(self, fontsize = 12):
        wordLength = self.wordLength
        if fontsize == 12:
            wordsOnPage = 300
        else:
            wordsOnPage = 300 - (fontsize - 12) * 10
        return round(wordLength / wordsOnPage)

        

myStoryBook = Novel("My Story Book", "StarsInDust", 100000)

print(myStoryBook.wordLength)
print(myStoryBook)