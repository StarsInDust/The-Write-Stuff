class Teacher:
    species = "Homo Sapiens"
    def __init__(self, name, subject):
        self.name = name
        self.subject = subject
        

MathTeacher = Teacher("Dan", "Math")
EnglishTeacher = Teacher("Mary", "Engish")


print (MathTeacher.name)
print(MathTeacher.subject)
print(EnglishTeacher.name)
print(EnglishTeacher.subject)

print(MathTeacher.species)
print(EnglishTeacher.species)