add =lambda w,x, y, z : (w + x) * y - z 
print(add(1,5,7,25))

