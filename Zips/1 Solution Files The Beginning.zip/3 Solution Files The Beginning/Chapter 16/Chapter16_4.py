myMood = ['Happy', 'We Are!'] * 3
print(myMood)
