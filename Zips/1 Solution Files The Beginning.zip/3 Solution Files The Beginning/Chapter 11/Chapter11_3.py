#determine if you can both vote and drink.

yourAge = 33

if yourAge < 18:
    print('You are a child, you cannot drink, or vote.')

elif yourAge < 21:
    print('You can vote, but you cannot drink')

else:
    print("Let's first go vote, and then go drink!")
