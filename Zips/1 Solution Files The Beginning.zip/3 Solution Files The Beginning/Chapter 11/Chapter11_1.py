#determine if adult

yourAge = 6

if yourAge < 18:
    print('You are a child, you cannot drink, or vote.')

