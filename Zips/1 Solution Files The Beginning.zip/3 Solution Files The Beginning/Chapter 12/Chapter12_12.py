#The outer loop Numbers will be written top to bottom

for i in range(0, 6):
    #Nested Loop
    #Numbers in inner loop will be written left to right
    for j in range(0, 5):
        #Print Addition
        print(i + j, end=' ')
    print()
