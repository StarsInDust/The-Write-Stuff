myFruitTupple = ("apple", "banana", "peach" )
for item in myFruitTupple:
    print(item)
