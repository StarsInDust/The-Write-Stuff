#using a while loop to get a whole number between 1 and 10.

num = 0

while True:
    try:
        num = int(input("Enter some whole number between 1-10: "))
    except ValueError:
        print("Please enter a valid whole number between 1-10:")
        continue
    if num >= 1 and num <= 10:
        print(f'Here is your number: {num}')
        break
    else:
        print('Your number needs to be between 1 and 10:')