import datetime

print(dir(datetime))

