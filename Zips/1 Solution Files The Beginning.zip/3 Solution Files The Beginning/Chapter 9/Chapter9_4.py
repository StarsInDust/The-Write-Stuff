def divideMe (x, y):
    if y ==0 or x == 0:
        
        return 'My custom message: You cannot divide by 0'
    else:
        return x/y

myAnswer = int(divideMe(90, 0))
print(myAnswer)