
import random

myNumber = random.randint(1,6)
print(myNumber)

