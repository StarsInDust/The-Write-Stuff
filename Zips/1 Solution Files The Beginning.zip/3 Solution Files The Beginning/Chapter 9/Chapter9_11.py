import random

myPick = ("witch", "dragon", "unicorn")

myPicks = random.choice(myPick)
print(myPicks)