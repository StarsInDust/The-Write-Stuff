def multiplyMe (x, y):
    return x * y

myAnswer = multiplyMe(3, 3)
print(myAnswer)