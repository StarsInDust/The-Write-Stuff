x = -8
assert (x >= 0)