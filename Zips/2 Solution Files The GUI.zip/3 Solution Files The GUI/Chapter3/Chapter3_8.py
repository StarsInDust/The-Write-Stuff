from tkinter import *


window = Tk()
window.title('I am a Listbox')
window.geometry ("500x400")
window.config(background="#400a84")
icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)


listbox = Listbox(window)
listbox.pack()


listbox.insert(1, 'Airplane')
listbox.insert(2, 'Boat')
listbox.insert(3, 'Car')
listbox.insert(4, 'Motor Cycle')
listbox.insert(5, 'Train')



window.mainloop()
