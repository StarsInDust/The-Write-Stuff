from tkinter import *


window = Tk()
window.title('My First GUI')
window.geometry("600x400")





window.mainloop()

