from tkinter import *

window=Tk()

window.title('Labels')
window.geometry('300x150')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#e4bdbf")



label = Label(window, text ="Hello World", font= ('Arial',40,'bold'))
label.config(bg = "#e4bdbf", fg= "black")
label.pack()

window.mainloop()