from tkinter import *

def doSomething(event):
   #print('You pressed: ' + event.keysym)
    label.config(text=event.keysym)




window = Tk()

window.title('Keyboard Events')
window.geometry('400x350')
window.config(background='#b7787a')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)



#window.bind('<Return>', doSomething)
 
window.bind('<Key>', doSomething)



label =Label(window, font=('Helvetica',50), width= 150, bg='#ddadaf', fg='#652517')
label.pack()



window.mainloop()
