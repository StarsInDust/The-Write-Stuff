from tkinter import *

def doSomething(event):
    print('Amazing, you absolutely did something!')


window = Tk()

window.title('Keyboard Events')
window.geometry('400x350')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)



#window.bind('<Return>', doSomething)
 
window.bind('<Key>', doSomething)



window.mainloop()
