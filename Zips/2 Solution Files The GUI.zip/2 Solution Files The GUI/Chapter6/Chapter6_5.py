from tkinter import *


def doSomething(event):
    print('Mouse Coordinates ' + str(event.x) +', ' + str(event.y))

def doThisInstead(event):
    print('You released the button')

def doThisToo(event):
    print('Do you like Chicken and Rice?')

def fineJustGo(event):
    print('You just left the window')


#def doSomethingMotion(event):
   #print('The mouse is in motion') 



window = Tk()

window.title('Mouse')
window.geometry('400x350')
window.config(background='#b7787a')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)


window.bind('<Button-3>', doSomething)

window.bind('<ButtonRelease>', doThisInstead)

window.bind('<Enter>', doThisToo)

window.bind('<Leave>', fineJustGo)

 #This one will override the rest so use it by itself.
#window.bind('<Motion>', doSomethingMotion)


window.mainloop()

