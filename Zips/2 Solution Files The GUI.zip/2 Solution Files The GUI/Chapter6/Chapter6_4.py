from tkinter import *


def doSomething(event):
    print('Mouse Coordinates ' + str(event.x) +', ' + str(event.y))



window = Tk()


window.title('Mouse')
window.geometry('400x350')
window.config(background='#b7787a')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)


'''window.bind('<Button-1>', doSomething)
window.bind('<Button-2>', doSomething)'''


window.bind('<Button-3>', doSomething)

window.mainloop()

