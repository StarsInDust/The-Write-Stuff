from tkinter import *
from tkinter.ttk import *
import time

def start():
    GB = 100
    download = 0
    speed = 1
    while( download<GB):
        time.sleep(0.1)
        bar['value']+=(speed/GB)*100
        download+=speed
        percent.set(str(int((download/GB)*100))+'%')
        text.set(str(download)+'/'+ str(GB) + ' GB completed')
        window.update_idletasks()

window = Tk()

window.title('Progress Bar')
window.geometry('400x200')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)

percent = StringVar()
text = StringVar()

bar = Progressbar(window, orient=HORIZONTAL, length = 300)
bar.pack(pady=10)

percentLabel = Label(window, textvariable=text).pack()
taskLabel = Label(window, textvariable=percent).pack()

button =Button(window, text='download', command=start).pack()

window.mainloop()
