from tkinter import *


window = Tk()
window.geometry("600x400")


window.mainloop()