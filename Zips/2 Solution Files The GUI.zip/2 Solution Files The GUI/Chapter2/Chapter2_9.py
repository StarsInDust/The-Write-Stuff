from tkinter import *


window = Tk()
window.title('A Button')
window.geometry("230x100")


icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#001400")

def clickMe():
    print('I see that you have now clicked the button.')


button = Button(
    window, 
    text='Click Me', 
    command=clickMe,
    font =("Helvetica",30),
    relief =RAISED,
    bd=7,
    fg="#001400",
    bg="#cff5cf"
    )


button.pack()

window.mainloop()
