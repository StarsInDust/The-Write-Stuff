from tkinter import *

window=Tk()

window.title('Radio Buttons')
window.geometry('320x150')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#001400")



food =["salad","steak","dessert"]

for index in range(len(food)):
    radioButton = Radiobutton(window,
    font =("Helvetica",18),  
    text =food[index],
    bg="#001400",
    fg='White' 
    )
    radioButton.pack()



window.mainloop()