from tkinter import *


window = Tk()
window.title('A Button')
window.geometry("230x35")


icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#e4bdbf")

button = Button(window)
button.pack()

window.mainloop()



