from tkinter import *

window=Tk()

window.title('A Check Button')
window.geometry('300x180')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#eaeaea")



check_button= Checkbutton(window,
text="I agree to something",
)

check_button.pack()




window.mainloop()