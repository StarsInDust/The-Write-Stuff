from tkinter import *


window = Tk()
window.title('A Button')
window.geometry("230x35")


icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#e4bdbf")

def clickMe():
    print('I see that you have now clicked the button.')




button = Button(window, text='Click Me', command=clickMe)
button.pack()

window.mainloop()
