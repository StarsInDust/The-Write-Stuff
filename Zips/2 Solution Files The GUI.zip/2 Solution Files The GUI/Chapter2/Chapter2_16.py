from tkinter import *

window=Tk()

window.title('A Check Button')
window.geometry('300x180')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#eaeaea")


def display():
    if(x.get()==1):
        print("You agree! :)")
    else:
        print("You do not agree :(")


x = IntVar()

check_button= Checkbutton(window,
text="I agree to something",
variable=x,
onvalue=1,
offvalue=0, 
command=display
)

check_button.pack()

window.mainloop()