from tkinter import *

window=Tk()

window.title('A Check Button')
window.geometry('500x220')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#001400")

photo = PhotoImage(file='images\PandV.png')


def display():
    if(x.get()==1):
        print("You agree! :)")
    else:
        print("You do not agree :(")


x = IntVar()

check_button= Checkbutton(window,
text="I agree to something",
variable=x,
onvalue=1,
offvalue=0, 
command=display,
font=('Times New Roman',14),
fg='#001400',
bg='#cff5cf',
activeforeground='#cff5cf',
activebackground='#1b6531',
padx=25,
pady=10,
image=photo,
compound='left'
)

check_button.pack()

window.mainloop()