from tkinter import *

window=Tk()

window.title('Put Title Here')
window.geometry('300x150')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)




window.mainloop()

