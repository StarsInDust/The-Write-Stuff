from tkinter import *

window=Tk()

window.title('Radio Buttons')
window.geometry('300x150')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)




window.mainloop()

