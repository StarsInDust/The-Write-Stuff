from tkinter import *

window=Tk()

window.title('Labels')
window.geometry('230x180')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#f7f4eb")

photo = PhotoImage(file='images\PandV.png')


label = Label(
    
window, 
text ="This is your label talking", 
font= ('Times New Roman',35,'bold'),
fg='#a05a5d',
bg='#f7f4eb',
relief =RAISED,
bd=5,
padx = 20,
pady = 20,
 

image=photo

)

label.pack()

window.mainloop()
