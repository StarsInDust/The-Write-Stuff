from tkinter import *

window=Tk()

window.title('A Button')
window.geometry('300x180')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#001400")

photo =PhotoImage(file='images\Press-Here.png')

count = 0

def countMe():
    global count
    count += 1
    print(count)


button = Button(
    window, 
    text='Count Me', 
    command=countMe,
    font =("Helvetica",30),
    relief =RAISED,
    bd=7,
    fg="#001400",
    bg="#cff5cf",
    activeforeground="#cff5cf",
    activebackground="#124212",
    state=ACTIVE,
    image=photo,
    compound= 'bottom'
    )


button.pack()


window.mainloop()
