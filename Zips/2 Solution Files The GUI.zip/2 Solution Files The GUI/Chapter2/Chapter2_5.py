from tkinter import *

window=Tk()

window.title('Labels')
window.geometry('600x500')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#f7f4eb")

photo = PhotoImage(file='images\PandV.png')


label = Label(
    
window, 
text ="Python & Visual Studio Code, This book is set up to teach you everything you want to know about Python and Visual Studio Code.", 
font= ('Times New Roman',25,'bold'),
fg='#a05a5d',
bg='#f7f4eb',
wraplength = 600,
justify="left",
relief =RAISED,
bd=5,
padx = 20,
pady = 20,
 

image=photo,
compound= 'bottom'

)

label.pack()

window.mainloop()