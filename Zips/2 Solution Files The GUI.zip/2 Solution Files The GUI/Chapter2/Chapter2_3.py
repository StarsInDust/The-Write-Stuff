from tkinter import *

window=Tk()

window.title('Labels')
window.geometry('600x150')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background="#e4bdbf")


label = Label(
    
window, 
text ="This is your label talking", 
font= ('Times New Roman',35,'bold'),
fg='#a05a5d',
bg='#e4bdbf',
relief =RAISED,
bd=5,
padx = 20,
pady = 20

)

label.pack()

window.mainloop()


