from tkinter import *


window=Tk()

window.title('Radio Buttons')
window.geometry('250x250')

icon= PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background= "#e7c6c7")

saladImage = PhotoImage(file="images\salad.png")
steakImage = PhotoImage(file="images\steak.png")
dessertImage = PhotoImage(file="images\dessert.png")

foodImages=[saladImage, steakImage, dessertImage]



food =["salad","steak","dessert"]

x=IntVar()

for index in range(len(food)):
    radiobutton = Radiobutton(window,
    font =("Helvetica,18"),
    bg="#e7c6c7", 
    text =food[index], 
    variable=x,
    value=index, 
    pady = 10,
    image = foodImages[index],
    compound='left',
    indicatoron=0,
    width = 250
    
    )
    radiobutton.pack()



window.mainloop()