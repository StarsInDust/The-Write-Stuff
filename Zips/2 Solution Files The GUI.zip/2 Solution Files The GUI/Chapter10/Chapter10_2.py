import tkinter as tk
from random import randint
from PIL import Image, ImageTk


MOVE_INCREMENT = 20
MOVES_PER_SECOND = 8
GAME_SPEED = 3000 // MOVES_PER_SECOND
WIDTH = 600
HEIGHT = 620


class Snake(tk.Canvas):
    def __init__(self):
        super().__init__(
            width=WIDTH, height=HEIGHT, background="Beige", highlightthickness=0 
        )

        self.snake_positions = [(300, 300)]
        self.food_position = self.set_new_food_position()
        self.bomb_position = self.set_new_bomb_position()
        self.heart_position = self.set_new_heart_position()

       
        self.direction = "Right"

        self.score = 1
        self.life = 1

        self.load_assets()
        self.create_objects()

        self.bind_all("<Key>", self.on_key_press)

        self.pack()

        self.after(GAME_SPEED, self.perform_actions)

        

    def load_assets(self):
        try:
            self.snake_body_image = Image.open("images\snake_double.png")
            self.snake_body = ImageTk.PhotoImage(self.snake_body_image)


            self.bomb_image = Image.open("images\wbomb.png")
            self.bomb = ImageTk.PhotoImage(self.bomb_image)

            self.heart_image = Image.open("images\wheart.png")
            self.heart = ImageTk.PhotoImage(self.heart_image)


            self.food_image = Image.open("images\wfood.png")
            self.food = ImageTk.PhotoImage(self.food_image)

    
        except IOError as error:
            print(error)
            window.destroy()



    def create_objects(self):
        self.create_text(
            55, 25, text=f"Score:{self.score} \nLives:{self.life}", tag="score", fill="#000000", font=("", 6)
        )

        for x_position, y_position in self.snake_positions:
            self.create_image(
                x_position, y_position, image=self.snake_body, tag="snake") 
            

        self.create_image(*self.food_position, image=self.food, tag="food")
        self.create_rectangle(7, 27, 593, 613, outline="Beige")
        

        self.create_image(*self.bomb_position, image=self.bomb, tag="bomb")
        

        self.create_image(*self.heart_position, image=self.heart, tag="heart")


    

    def check_collisions(self):
        head_x_position, head_y_position = self.snake_positions[0]


        try:

            if head_x_position in (0, 600): 

                self.direction = "Left"
                
                print('You collided right')

            if head_x_position in (20, 620): 

                self.direction = "Right"
                print('You collided left')
            
            
            if head_y_position in (0,620):
               self.direction = "Up"
               print('You have hit bottom')
              
            if head_y_position in (0,20):
               self.direction = "Down"
               print('You have hit Top of screen')
               
        except Exception as e:
            print(e)

        return (
          
            
             self.life ==0
            or self.life and self.score ==0
            
            
        )

    def check_food_collision(self):
        if self.snake_positions[0] == self.food_position:
            self.score += 3 
             

            self.food_position = self.set_new_food_position()
            self.coords(self.find_withtag("food"), *self.food_position)

            score = self.find_withtag("score")
            self.itemconfigure(score, text=f"Score:{self.score} \nLives:{self.life}", 
            tag="score", fill="#000000", font=("", 6))


    def check_bomb_collision(self):

        try:
            if self.snake_positions[0] == self.bomb_position:
             self.score -= 1 
             self.life -= 1 

             self.bomb_position = self.set_new_bomb_position()
             self.coords(self.find_withtag("bomb"), *self.bomb_position)

             score = self.find_withtag("score")
             self.itemconfigure(score, text=f"Score:{self.score} \nLives:{self.life}", 
             tag="score", fill="#000000", font=("", 6))
        except Exception as e:
            print(e)




    def check_heart_collision(self):

        try:
            if self.snake_positions[0] == self.heart_position:
              
             self.life += 1 

             self.heart_position = self.set_new_heart_position()
             self.coords(self.find_withtag("heart"), *self.heart_position)

             score = self.find_withtag("score")
             self.itemconfigure(score, text=f"Score:{self.score} \nLives:{self.life}", 
             tag="score", fill="#000000", font=("", 6))
        except Exception as e:
            print(e)

    

    def end_game(self):
        self.delete(tk.ALL)
        self.create_text(
            self.winfo_width() / 2,
            self.winfo_height() / 2,
            text=f"Game over! You scored {self.score}! \nLives:{self.life}!",
            fill="#000000",
            font=("", 11)
        )

    def move_snake(self):
        head_x_position, head_y_position = self.snake_positions[0]

        if self.direction == "Left":
             new_head_position = (head_x_position - MOVE_INCREMENT, head_y_position, ) 
            
        elif self.direction == "Right":
            new_head_position = (head_x_position + MOVE_INCREMENT, head_y_position) 
            
        elif self.direction == "Down":
            new_head_position = (head_x_position, head_y_position + MOVE_INCREMENT) 
           
        elif self.direction == "Up":
            new_head_position = (head_x_position, head_y_position - MOVE_INCREMENT)

        self.snake_positions = [new_head_position] 

        

        for segment, position in zip(self.find_withtag("snake"), self.snake_positions):
            self.coords(segment, position)

    def on_key_press(self, e):
        new_direction = e.keysym
        


        all_directions = ("Up", "Down", "Left", "Right")
        opposites = ({"Up", "Down"}, {"Left", "Right"})

        if (
            new_direction in all_directions
            and {new_direction, self.direction} not in opposites

        ):
            self.direction = new_direction

            

    def perform_actions(self):
        if self.check_collisions():
            self.end_game()

        self.check_bomb_collision()
        self.check_heart_collision()
        self.check_food_collision()
        self.move_snake()

        self.after(GAME_SPEED, self.perform_actions)

    def set_new_food_position(self):
        while True:
            x_position = randint(1, 29) * MOVE_INCREMENT
            y_position = randint(3, 30) * MOVE_INCREMENT
            food_position = (x_position, y_position)

            if food_position not in self.snake_positions:

                return food_position


    def set_new_bomb_position(self):
        while True:
            x_position = randint(1, 29) * MOVE_INCREMENT
            y_position = randint(3, 30) * MOVE_INCREMENT
            bomb_position = (x_position, y_position)

            if bomb_position not in self.snake_positions:

                 return bomb_position

    def set_new_heart_position(self):
        while True:
            x_position = randint(1, 29) * MOVE_INCREMENT
            y_position = randint(3, 30) * MOVE_INCREMENT
            heart_position = (x_position, y_position)

            if heart_position not in self.snake_positions:

                 return heart_position


window = tk.Tk()
window.title("Python Snake Game")
window.resizable(False, False)
window.tk.call("tk", "scaling", 4.0)

icon = ImageTk.PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)


board = Snake()
board.pack()

window.mainloop()
