from tkinter import *
from Ball import *
import time

window = Tk()

WIDTH = 500
HEIGHT = 500


window.title('Multiple Animations')
window.geometry('400x400')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)


canvas = Canvas(window, width=WIDTH, height=HEIGHT)
canvas.pack()

volley_ball = Ball(canvas,0,0,100,1,1,"pink")
basket_ball = Ball(canvas,3,0,135,3,10,"orange")
base_ball = Ball(canvas,0,5,30,10,1,"indigo")

while True:
    volley_ball.move()
    basket_ball.move()
    base_ball .move()
    window.update()
    time.sleep(0.01)


window.mainloop()
