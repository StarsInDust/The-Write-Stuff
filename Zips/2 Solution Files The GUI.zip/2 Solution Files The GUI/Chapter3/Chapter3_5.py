from tkinter import *


window = Tk()
window.title('This is an entry widget')
window.geometry ("600x100")
window.config(background="#400a84")
icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)

def submit():
    username = entry.get()
    print("Hello " + username)
    entry.config(state= DISABLED)


def delete():
    entry.delete(0,END)

def backspace():
   entry.delete(len(entry.get())-1, END)


entry=Entry(window,
 font=("Georgia", 25), 
 bg="#400a84", 
 fg="#ffffff"

)

entry.insert(0," Please Enter Your Name")
entry.pack(side = LEFT)



submitButton= Button(window, text='submit', command=submit)
submitButton.pack(side=RIGHT)

delete_button= Button(window, text="delete", command=delete)
delete_button.pack(side=RIGHT)

backspace_button= Button(window, text="backspace", command=backspace)
backspace_button.pack(side=RIGHT)


window.mainloop()
