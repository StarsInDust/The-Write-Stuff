from tkinter import *

def submit():
    print('Your choice of transportion is: ')
    print(listbox.get(listbox.curselection()))
   
window = Tk()
window.title('I am a Listbox')
window.geometry ("500x300")
window.config(background="#01211e")
icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)


listbox = Listbox(window,
    font=("Constantia", 15),
    fg= "#f0f4f5",
    bg= "#01211e",
    width=28,
    relief =RAISED,
    bd=5
    )
listbox.pack()


listbox.insert(1, 'Airplane')
listbox.insert(2, 'Boat')
listbox.insert(3, 'Car')
listbox.insert(4, 'Motor Cycle')
listbox.insert(5, 'Train')

listbox.config(height=listbox.size())

submitbutton = Button(window,text='submit', command=submit)
submitbutton.pack()



window.mainloop()
