from tkinter import *
from tkinter import messagebox


window =Tk()
window.title('Message Boxes')
window.geometry('300x200')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon) 



def click():
    messagebox.showinfo(title='Info Message ', message="This is a message")

    '''

def click():
    messagebox.showwarning(title='Warning Message', message="I am Warning You!")




def click():
    messagebox.showerror(title='Error Message', message="Danger, Danger!")
'''

button = Button(window, text ='click me!', command=click)
button.pack()


window.mainloop()