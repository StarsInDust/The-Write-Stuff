from tkinter import *


window = Tk()
window.title('This is an entry widget')
window.geometry ("500x100")
window.config(background="#400a84")
icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)

def submit():
    username = entry.get()
    print("Hello" + username)


entry=Entry(window,
 font=("Georgia", 25), 
 bg="#400a84", 
 fg="#ffffff",
)
entry.pack(side = LEFT)


submitButton= Button(window, text='submit', command=submit)
submitButton.pack(side=BOTTOM)


window.mainloop()
