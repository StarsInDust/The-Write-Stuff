
from tkinter import * 
from tkinter.ttk import *
from tkinter import ttk

  
# creating tkinter window
window = Tk()
window.title('Frames')
window.geometry('400x400')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)


myStyle = ttk.Style()
myStyle.configure('My.TFrame', background='#ddadaf')
  
# Add the Frame
frame =Frame(window, style='My.TFrame')
frame.place(x=25, y=25)


  
# Creating a photoimage object to use image
witch = PhotoImage(file = r"images\witch.png")
ant = PhotoImage(file = r"images\want.png")
snake = PhotoImage(file = r"images\snake.png")
dragon = PhotoImage(file = r"images\wdragon.png")


  
# Resizing image to fit on button
photoimage1 = witch.subsample(1, 1)
photoimage2 = ant.subsample(1, 1)
photoimage3 = snake.subsample(1, 1)
photoimage4 = dragon.subsample(1, 1)

#Instead of setting to window, set each button to frame
  

Button(frame, image = photoimage1, width =1).pack(side = TOP)
Button(frame, image = photoimage2, width =1).pack(side = LEFT)
Button(frame, image = photoimage3, width =1).pack(side = LEFT)
Button(frame, image = photoimage4, width =1).pack(side = LEFT)
  
mainloop()