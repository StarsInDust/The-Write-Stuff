
from tkinter import *

def create_window():
    new_window= Tk()
    new_window.geometry('320x300')
    new_window.title('I am a new window!')
    new_window.config(background='#b7787a')

window = Tk()

window.title('New Windows')
window.geometry('400x350')
window.config(background='#2F5688')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)

Button(window, text='Click here for new window!', command=create_window,font= ('Lucida Calligraphy',11), bg='#25375F', fg='#fcf7f7' ).pack()


window.mainloop()

