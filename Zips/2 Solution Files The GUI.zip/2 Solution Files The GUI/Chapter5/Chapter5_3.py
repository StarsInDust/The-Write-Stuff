from tkinter import *

window = Tk()
window.title('Canvas')
window.geometry('400x400')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)


canvas = Canvas(window, height = 400, width = 400)
roon= canvas.create_line(0,0,400,400, fill='maroon', width=2)
idgo = canvas.create_line(0,400,400,0, fill='indigo', width=4)
blk = canvas.create_line(50,30,30,50, fill='black', width=9)

canvas.pack()



window.mainloop()
