from tkinter import *

def create_window():
    new_window= Tk()
    new_window.geometry('320x300')
    new_window.title('I am a new window!')
    new_window.config(background='#b7787a')

    old_window.destroy()

old_window = Tk()
old_window.title('Create New Windows')
old_window.geometry('400x400')
old_window.config(background='#2F5688')

icon =PhotoImage(file= 'images\icon.png')
old_window.iconphoto(True, icon) 

Button(old_window, text='create new window', command=create_window,font= ('Lucida Calligraphy',11), bg='#25375F', fg='#fcf7f7').pack()


old_window.mainloop()
