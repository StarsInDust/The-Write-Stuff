from tkinter import *


window = Tk()
window.title('Frames')
window.geometry('400x300')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)

frame =Frame(window, bg='#ddadaf', bd=5, relief=RAISED)
frame.pack()



Button(frame, text='A', font=('Consolas',20), width=3).pack(side=TOP)
Button(frame, text='B', font=('Consolas',20), width=3).pack(side=LEFT)
Button(frame, text='C', font=('Consolas',20), width=3).pack(side=LEFT)
Button(frame, text='D', font=('Consolas',20), width=3).pack(side=LEFT)




window.mainloop()


