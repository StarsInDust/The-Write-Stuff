from tkinter import *

window = Tk()
window.title('Canvas')
window.geometry('400x400')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)

canvas = Canvas(window, height = 400, width = 400)


# SHAPES

roon= canvas.create_line(0,0,400,400, fill='maroon', width=2)
idgo = canvas.create_line(0,400,400,0, fill='indigo', width=4)
blk = canvas.create_line(50,30,30,50, fill='black', width=9)

'''

canvas.create_rectangle(10, 10, 200, 50, fill='purple', outline='gold')

canvas.create_oval(10, 10, 200, 150, fill='green', outline='red')

canvas.create_polygon(10, 10, 200, 50, 90, 150, 50, 80, 120, 55, fill='orange', outline='blue')

canvas.create_arc(10, 10, 200, 150, fill='navy', outline='black', start=45, extent=135, width=5)


# IMAGES
#Make sure you have an image in the folder, and put in the correct relative path

myimg = PhotoImage(file='images\PandV.png')
canvas.create_image(10, 10, image=myimg, anchor='nw')


# TEXT

canvas.create_text(100, 100, text='A wonderful story', anchor='nw', font='TkMenuFont', fill='indigo')
'''
# WIDGETS

b = Button(canvas, text='Click Me!')
canvas.create_window(10, 10, anchor='nw', window=b)

canvas.pack()

window.mainloop()
