from tkinter import *
from tkinter import filedialog

window =Tk()
window.title('File Dialog')
window.geometry('400x400')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)

def openFile():

   filepath = filedialog.askopenfilename(initialdir='ExtraProjectFiles', 
   
   title= 'Please choose the file that you want',
   filetypes=(('text files', '*.txt'),
   ('all files','*.*'))
   
   
   )
   

   file = open(filepath,'r')
   print(file.read())
   file.close()


button = Button(window, text ='Open', command=openFile)
button.pack()

window.mainloop()

